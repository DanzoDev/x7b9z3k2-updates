const { createApp, ref, computed, onMounted, watch } = Vue;

        createApp({
            setup() {
                const loading = ref(true);
                const activeTab = ref('commands');
                const navExpanded = ref(false);
                const searchQuery = ref('');
                const showInfoCommandModal = ref(false);
                const showAddCommandModal = ref(false);
                const showEditCommandModal = ref(false);
                const showInfoHotkeyModal = ref(false);
                const playerCount = ref('--');
                const hotkeySearchQuery = ref('');
                const linkSearchQuery = ref('');
                const showAddHotkeyModal = ref(false);
                const showEditHotkeyModal = ref(false);
                const isListeningEdit = ref(false);
                const editHotkey = ref({ oldKey: '', key: '', command: '' });


                const setupWindowControls = () => {
                    const bridge = window.chrome?.webview?.hostObjects?.sync?.csharpBridge;
                    if (!bridge) {
                        console.warn("C# Bridge (csharpBridge) nicht gefunden für Fenstersteuerung.");
                        return;
                    }

                    const titleBar = document.getElementById('window-title-bar');
                    const minBtn = document.getElementById('minimize-btn');
                    const maxBtn = document.getElementById('maximize-btn');
                    const closeBtn = document.getElementById('close-btn');

                    if (titleBar) {
                        titleBar.addEventListener('mousedown', (e) => {
                            if (e.buttons === 1) {
                                let target = e.target;
                                let isButton = false;
                                while(target) {
                                    if (target.classList && target.classList.contains('window-btn')) {
                                        isButton = true;
                                        break;
                                    }
                                    if (target.id === 'window-title-bar') break;
                                    target = target.parentElement;
                                }

                                if (!isButton) {
                                    bridge.DragWindow();
                                }
                            }
                        });
                    }

                    if (minBtn) minBtn.addEventListener('click', () => bridge.MinimizeWindow());
                    if (maxBtn) maxBtn.addEventListener('click', () => bridge.MaximizeWindow());
                    if (closeBtn) closeBtn.addEventListener('click', () => bridge.CloseWindow());
                };

                const filteredHotkeys = computed(() => {
                    const search = hotkeySearchQuery.value.toLowerCase();
                    return Object.entries(hotkeys.value)
                        .filter(([key, command]) =>
                            key.toLowerCase().includes(search) ||
                            command.toLowerCase().includes(search)
                        )
                        .map(([key, command]) => ({ key, command }));
                });

                const filteredLinks = computed(() => {
                    const search = linkSearchQuery.value.toLowerCase();
                    return links.value.filter(link =>
                        link.name.toLowerCase().includes(search) ||
                        link.url.toLowerCase().includes(search)
                    );
                });

                const version = ref('[DEVELOPMENT]');

                const commands = ref({});
                const counters = ref({
                    daily: 0,
                    weekly: 0,
                    total: 0
                });
                const drugData = ref({
                    DrugLevel: 1,
                    Enabled: true,
                    DrugCooldownEnd: null
                });
                const drugWorker = ref({
                    running: false,
                    cooldown: 0
                });
                const hotkeys = ref({});
                const newHotkey = ref({ key: '', command: '' });

                const logFiles = ref([]);
                const selectedLogContent = ref('');
                const selectedLogName = ref('');

                const settings = ref({
                    ShowOverlay: true,
                    OverlaySize: 100,
                    ShowWeeklyBox: true,
                    ShowDrugCooldown: true,
                    ShowAirdrop: true,
                    AirdropSoundVolume: 20,
                    EnableAirdropSound: true,
                    DrugSoundVolume: 50,
                    EnableDrugSound: true,
                    MoveStopEnabled: true,
                    EnableHotkeys: true,

                    OverlayColor: "#4287f5",

                    ColorBackground: "#18181b",
                    ColorPanel: "#27272a",
                    ColorInput: "#3f3f46",
                    ColorBorder: "#3f3f46",
                    ColorTextMuted: "#a1a1aa"
                });
                const newCommand = ref({
                    key: '',
                    value: ''
                });
                const editCommand = ref({
                    oldKey: '',
                    key: '',
                    value: ''
                });
                const executerTextbox = ref('');

                const notes = ref([])
                const noteSearchQuery = ref('');
                const tabs = ref([
                    { id: 'commands', name: 'Befehle', icon: 'fas fa-terminal' },
                    { id: 'stats', name: 'Statistiken', icon: 'fas fa-chart-bar' },
                    { id: 'drugs', name: 'Drogentool', icon: 'fas fa-pills' },
                    { id: 'hotkeys', name: 'Hotkeys', icon: 'fas fa-keyboard' },
                    { id: 'cmdexecuter', name: 'Executer', icon: 'fas fa-file-arrow-up' },
                    { id: 'links', name: 'Links', icon: 'fas fa-link' },
                    { id: 'notes', name: 'Notizen', icon: 'fas fa-clipboard' },
                    { id: 'settings', name: 'Einstellungen', icon: 'fas fa-cog' }
                ]);

                const links = ref([
                    { name: 'Allgemeine Regeln', url: 'https://forum.gta5majestic.com/threads/allgemeine-regeln.183781/', icon: 'fa fa-link' },
                    { name: 'Regeln für staatliche Organisationen', url: 'https://forum.gta5majestic.com/threads/regeln-fur-staatliche-organisationen.183783/', icon: 'fa fa-link' },
                    { name: 'Regeln für kriminelle Organisationen & Aktivitäten', url: 'https://forum.gta5majestic.com/threads/regeln-fur-kriminelle-organisationen-aktivitaten.183784/', icon: 'fa fa-link' },
                    { name: 'Regeln für Familien & Clans', url: 'https://forum.gta5majestic.com/threads/regeln-fur-familien-clans.183785/', icon: 'fa fa-link' },
                    { name: 'Regeln für den Angriff auf das Fort Zancudo & Cayo Perico', url: 'https://forum.gta5majestic.com/threads/regeln-fur-den-angriff-auf-das-fort-zancudo-cayo-perico.183786/', icon: 'fa fa-link' },
                    { name: 'Regeln für Territorial-Kämpfe (Turf)', url: 'https://forum.gta5majestic.com/threads/regeln-fur-territorial-kampfe-turf.183790/', icon: 'fa fa-link' },
                    { name: 'Regeln für Crafting & Konvoi', url: 'https://forum.gta5majestic.com/threads/regeln-fur-crafting-konvoi.183791/', icon: 'fa fa-link' },
                    { name: 'Regeln für den Angriff auf Organisationen (Razzia & Raid)', url: 'https://forum.gta5majestic.com/threads/regeln-fur-den-angriff-auf-organisationen-razzia-raid.183793/', icon: 'fa fa-link' },
                    { name: 'Regeln für Laden- & Bankraub', url: 'https://forum.gta5majestic.com/threads/regeln-fur-laden-bankraub.183794/', icon: 'fa fa-link' },
                    { name: 'Regeln für Leader', url: 'https://forum.gta5majestic.com/threads/regeln-fur-leader.183795/', icon: 'fa fa-link' },
                    { name: 'Regeln für den AirDrop & Übernahme von Dealer/Warenhäuser', url: 'https://forum.gta5majestic.com/threads/regeln-fur-den-airdrop-ubernahme-von-dealer-warenhhauser.183792/', icon: 'fa fa-link' },
                    { name: 'Tool Discord Server', url: 'https://discord.gg/5Rfn4KTq', icon: 'fab fa-discord' },
                ]);

                const showWeekChart = ref(true);
                const weeksToShow = ref(8);
                const weeklyStats = ref([]);
                const monthlyStats = ref([]);

                const correctSettingsTypes = (settings) => {
                    const defaults = {
                        ColorBackground: "#18181b",
                        ColorPanel: "#27272a",
                        ColorInput: "#3f3f46",
                        ColorBorder: "#3f3f46",
                        ColorTextMuted: "#a1a1aa",
                        OverlayColor: "#4287f5"
                    };

                    return {
                        ...settings,
                        OverlaySize: Number(settings.OverlaySize) || 100,
                        ShowOverlay: Boolean(settings.ShowOverlay),
                        ShowWeeklyBox: Boolean(settings.ShowWeeklyBox),
                        ShowDrugCooldown: Boolean(settings.ShowDrugCooldown),
                        ShowAirdrop: Boolean(settings.ShowAirdrop),
                        EnableAirdropSound: Boolean(settings.EnableAirdropSound),
                        AirdropSoundVolume: Number(settings.AirdropSoundVolume) || 22,
                        EnableDrugSound: Boolean(settings.EnableDrugSound),
                        DrugSoundVolume: Number(settings.DrugSoundVolume) || 50,
                        MoveStopEnabled: Boolean(settings.MoveStopEnabled),
                        EnableHotkeys: Boolean(settings.EnableHotkeys),

                        OverlayColor: String(settings.OverlayColor || defaults.OverlayColor),
                        ColorBackground: String(settings.ColorBackground || defaults.ColorBackground),
                        ColorPanel: String(settings.ColorPanel || defaults.ColorPanel),
                        ColorInput: String(settings.ColorInput || defaults.ColorInput),
                        ColorBorder: String(settings.ColorBorder || defaults.ColorBorder),
                        ColorTextMuted: String(settings.ColorTextMuted || defaults.ColorTextMuted)
                    };
                };

                function createDebounce(fn, delay = 500) {
                    let timer = null;
                    const wrapped = (...args) => {
                        clearTimeout(timer);
                        timer = setTimeout(() => fn(...args), delay);
                    };
                    wrapped.cancel = () => clearTimeout(timer);
                    return wrapped;
                }

                window.sendNotes = function(data) {
                    try {
                        if (Array.isArray(data)) notes.value = data;
                        else notes.value = [];
                    } catch (e) {
                        console.error("Fehler beim Laden der Notizen:", e);
                        notes.value = [];
                    }
                };

                const flushAllDebounces = () => {
                    debouncers.forEach((debounceFn, id) => {
                        try {
                            debounceFn.cancel?.();

                            const note = notes.value.find(n => n.Id === id);
                            if (note) updateNote(note);
                        } catch (e) {
                            console.error("Fehler beim Flush von Debounce:", e);
                        }
                    });

                    debouncers.clear();
                };

                const addNote = () => {
                    try {
                        flushAllDebounces();

                        window.chrome.webview.hostObjects.sync.csharpBridge.AddNote("Neue Notiz...");
                    } catch (e) {
                        console.error("Fehler beim Hinzufügen:", e);
                    }
                };

                const updateNote = (note) => {
                    try {
                        window.chrome.webview.hostObjects.sync.csharpBridge.UpdateNote(note.Id, note.Text);
                    } catch (e) {
                        console.error("Fehler beim Speichern:", e);
                    }
                };

                const debouncers = new Map();
                const onInputNote = (note) => {
                    if (!debouncers.has(note.Id)) {
                        debouncers.set(note.Id, createDebounce(updateNote, 600));
                    }
                    debouncers.get(note.Id)(note);
                };

                const deleteNote = (id) => {
                    if (!confirm("Diese Notiz wirklich löschen?")) return;
                    try {
                        flushAllDebounces();
                        window.chrome.webview.hostObjects.sync.csharpBridge.DeleteNote(id);
                    } catch (e) {
                        console.error("Fehler beim Löschen:", e);
                    }
                };

                const copyNote = (note) => {
                    navigator.clipboard.writeText(note.Text);
                };

                const filteredNotes = computed(() => {
                    const q = noteSearchQuery.value.toLowerCase();
                    return notes.value.filter((n) => n.Text.toLowerCase().includes(q));
                });


                let settingsTimeout = null;
                watch(settings, (newSettings) => {
                    clearTimeout(settingsTimeout);

                    settingsTimeout = setTimeout(() => {
                        const correctedSettings = correctSettingsTypes(newSettings);

                        console.log("Settings geändert - sende an Server:", correctedSettings);
                        sendBridge("UpdateSettings", JSON.stringify(correctedSettings));

                        updateThemeColors(correctedSettings);
                    }, 100);
                }, { deep: true });

                const updateThemeColors = (themeSettings) => {
                    const root = document.documentElement;

                    const accentColor = themeSettings.OverlayColor || '#4287f5';
                    root.style.setProperty('--accent-color', accentColor);

                    root.style.setProperty('--color-background', themeSettings.ColorBackground || '#18181b');
                    root.style.setProperty('--color-panel', themeSettings.ColorPanel || '#27272a');
                    root.style.setProperty('--color-input', themeSettings.ColorInput || '#3f3f46');
                    root.style.setProperty('--color-border', themeSettings.ColorBorder || '#3f3f46');
                    root.style.setProperty('--color-text-muted', themeSettings.ColorTextMuted || '#a1a1aa');

                    const darkenColor = (hexColor, percent) => {
                        if (!hexColor || typeof hexColor !== 'string') hexColor = '#4287f5';
                        hexColor = hexColor.replace('#', '');

                        let r = parseInt(hexColor.substr(0, 2), 16) || 0;
                        let g = parseInt(hexColor.substr(2, 2), 16) || 0;
                        let b = parseInt(hexColor.substr(4, 2), 16) || 0;

                        r = Math.max(0, Math.floor(r * (1 - percent/100)));
                        g = Math.max(0, Math.floor(g * (1 - percent/100)));
                        b = Math.max(0, Math.floor(b * (1 - percent/100)));

                        return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
                    };

                    const hoverColor = darkenColor(accentColor, 15);
                    const darkerColor = darkenColor(accentColor, 30);
                    const logoDarkColor = darkenColor(accentColor, 0);

                    const gradient = `linear-gradient(135deg, ${accentColor} 0%, ${hoverColor} 100%)`;
                    const hoverGradient = `linear-gradient(135deg, ${hoverColor} 0%, ${darkerColor} 100%)`;
                    const logoGradient = `linear-gradient(135deg, ${darkerColor} 0%, ${logoDarkColor} 100%)`;

                    root.style.setProperty('--accent-color-hover', hoverColor);

                    root.style.setProperty('--accent-gradient', gradient);
                    root.style.setProperty('--accent-hover', hoverGradient);
                    root.style.setProperty('--logo-gradient', logoGradient);
                };

                const calculateWeeklyStats = () => {
                    const stats = [];
                    const now = new Date();

                    for (let i = weeksToShow.value - 1; i >= 0; i--) {
                        const date = new Date(now);
                        date.setDate(date.getDate() - i * 7);

                        const year = date.getFullYear();
                        const weekNumber = getWeekNumber(date);
                        const weekKey = `${year}-W${weekNumber}`;

                        const weekStart = new Date(date);
                        weekStart.setDate(date.getDate() - date.getDay() + 1);
                        const weekEnd = new Date(weekStart);
                        weekEnd.setDate(weekStart.getDate() + 6);

                        const weekLabel = `KW ${weekNumber} (${formatDate(weekStart)} - ${formatDate(weekEnd)})`;
                        const weekShort = `KW ${weekNumber}`;

                        const count = counters.value.WeeklyStats?.[weekKey] || 0;

                        stats.push({
                            weekKey,
                            weekLabel,
                            weekShort,
                            count,
                            weekNumber,
                            year
                        });
                    }

                    return stats;
                };

                const getWeekNumber = (date) => {
                    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
                    const dayNum = d.getUTCDay() || 7;
                    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
                    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
                    return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
                };

                const formatDate = (date) => {
                    return date.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' });
                };

                const getBarHeight = (count) => {
                    const maxCount = Math.max(...weeklyStats.value.map(w => w.count), 1);
                    return (count / maxCount) * 80;
                };

                const getWeekColorClass = (count) => {
                    const avg = getAverageWeeklyCount();
                    if (count === 0) return 'bg-gray-500';
                    if (count < avg * 0.7) return 'bg-red-500';
                    if (count > avg * 1.3) return 'bg-green-500';
                    return 'bg-yellow-500';
                };

                const getMinWeeklyCount = () => {
                    return Math.min(...weeklyStats.value.map(w => w.count));
                };

                const getMaxWeeklyCount = () => {
                    return Math.max(...weeklyStats.value.map(w => w.count));
                };

                const getAverageWeeklyCount = () => {
                    const validWeeks = weeklyStats.value.filter(w => w.count > 0);
                    if (validWeeks.length === 0) return 0;
                    const sum = validWeeks.reduce((acc, w) => acc + w.count, 0);
                    return Math.round(sum / validWeeks.length);
                };

                const getLastWeekCount = () => {
                    if (weeklyStats.value.length < 2) return 0;
                    return weeklyStats.value[weeklyStats.value.length - 2].count;
                };

                const getWeekTrend = () => {
                    const current = getCurrentWeekCount();
                    const last = getLastWeekCount();

                    if (last === 0) return current > 0 ? '↑ Neu' : '→ Gleich';

                    const diff = current - last;
                    const percentage = Math.round((diff / last) * 100);

                    if (diff > 0) return `↑ +${percentage}%`;
                    if (diff < 0) return `↓ ${percentage}%`;
                    return '→ Gleich';
                };

                const getTrendColor = () => {
                    const trend = getWeekTrend();
                    if (trend.includes('↑')) return 'text-green-400';
                    if (trend.includes('↓')) return 'text-red-400';
                    return 'text-yellow-400';
                };

                const calculateMonthlyStats = () => {
                    const stats = [];
                    const now = new Date();

                    for (let i = 5; i >= 0; i--) {
                        const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
                        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
                        const monthName = date.toLocaleDateString('de-DE', { month: 'short' });
                        const monthShort = `${monthName} ${date.getFullYear().toString().slice(2)}`;

                        const count = Math.floor(Math.random() * 50) + 10;

                        stats.push({
                            monthKey,
                            monthShort,
                            count
                        });
                    }

                    return stats;
                };

                watch(weeksToShow, () => {
                    weeklyStats.value = calculateWeeklyStats();
                });

                const onExecuterTextChange = () => {
                    const text = executerTextbox.value.trim();
                    if (text === "" || text.length === 0) {
                        return;
                    }
                    sendBridge("sendExecuterText", executerTextbox.value);
                };

                const setStatusDrugWorker = () => {
                    drugWorker.value.Enabled = !drugWorker.value.Enabled;
                    sendBridge("statusDrugworker", drugWorker.value.Enabled);
                };

                onMounted(() => {
                    updateThemeColors(settings.value);
                    weeklyStats.value = calculateWeeklyStats();
                    monthlyStats.value = calculateMonthlyStats();
                });

                watch(counters, () => {
                    weeklyStats.value = calculateWeeklyStats();
                }, { deep: true });

                const filteredCommands = computed(() => {
                    const search = searchQuery.value.toLowerCase();
                    return Object.entries(commands.value)
                        .filter(([key, value]) =>
                            key.toLowerCase().includes(search) ||
                            value.toLowerCase().includes(search)
                        )
                        .map(([key, value]) => ({ key, value }));
                });

                const activeTabName = computed(() => {
                    const tab = tabs.value.find(t => t.id === activeTab.value);
                    return tab ? tab.name : '';
                });

                if (document.readyState === 'complete') {
                    console.log("document ready to request data");
                    const interval = setInterval(() => {
                        if (loading.value) {
                            window.chrome.webview.hostObjects.csharpBridge.requestData();
                            console.log("Datenanforderung gesendet");
                        } else {
                            clearInterval(interval);
                        }
                    }, 4000);
                } else {
                    console.log("document not ready to request data");
                    window.addEventListener('load', () => {
                        const interval = setInterval(() => {
                            if (loading.value) {
                                window.chrome.webview.hostObjects.csharpBridge.requestData();
                                console.log("Datenanforderung gesendet2");
                            } else {
                                clearInterval(interval);
                            }
                        }, 4000);
                    });
                }

                window.updateDrugWorkerStatus = function(status) {
                    drugWorker.value.running = status;
                };

                window.updateReplacements = function(data) {
                    console.log("updateReplacements aufgerufen", data);
                    commands.value = data;
                };

                window.updateAllData = function(data) {
                    if (!data) {
                        console.error("Keine Daten empfangen");
                        return;
                    }

                    console.log("Debug Data:", data);

                    if (data.replacements) {
                        commands.value = data.replacements;
                    }
                    if (data.hotkeys) {
                        hotkeys.value = data.hotkeys;
                    }
                    if (data.overlaysettings) {
                        const defaultSettings = settings.value;

                        settings.value.ShowOverlay = data.overlaysettings.IsVisible;
                        settings.value.OverlaySize = data.overlaysettings.Size;
                        settings.value.ShowWeeklyBox = data.overlaysettings.ShowWeeklyBox;
                        settings.value.ShowDrugCooldown = data.overlaysettings.ShowDrugCooldown;
                        settings.value.ShowAirdrop = data.overlaysettings.ShowAirdrop;
                        settings.value.AirdropSoundVolume = data.overlaysettings.AirdropSoundVolume;
                        settings.value.EnableAirdropSound = data.overlaysettings.EnableAirdropSound;
                        settings.value.EnableDrugSound = data.overlaysettings.EnableDrugSound;
                        settings.value.DrugSoundVolume = data.overlaysettings.DrugSoundVolume;
                        settings.value.MoveStopEnabled = data.overlaysettings.MoveStopEnabled;

                        settings.value.OverlayColor = data.overlaysettings.OverlayColor || defaultSettings.OverlayColor;
                        settings.value.ColorBackground = data.overlaysettings.ColorBackground || defaultSettings.ColorBackground;
                        settings.value.ColorPanel = data.overlaysettings.ColorPanel || defaultSettings.ColorPanel;
                        settings.value.ColorInput = data.overlaysettings.ColorInput || defaultSettings.ColorInput;
                        settings.value.ColorBorder = data.overlaysettings.ColorBorder || defaultSettings.ColorBorder;
                        settings.value.ColorTextMuted = data.overlaysettings.ColorTextMuted || defaultSettings.ColorTextMuted;

                        updateThemeColors(settings.value);
                    }
                    if (data.drugdata) {
                        drugData.value = data.drugdata;
                    }
                    if(data.counters) {
                        counters.value = data.counters;
                    }

                    if (data.playerCount !== undefined) {
                        playerCount.value = data.playerCount.toString();
                    }

                    if (data.notes) {
                        notes.value = data.notes;
                    }

                    if(data.version) version.value = data.version;

                    console.log("updateAllData abgeschlossen");
                    loading.value = false;
                };

                const sendBridge = (methodName, ...args) => {
                    if (window.chrome?.webview?.hostObjects?.sync?.csharpBridge) {
                        window.chrome.webview.hostObjects.sync.csharpBridge[methodName](...args);
                    } else {
                        console.error("C# Bridge nicht verfügbar");
                    }
                };

                const addCommand = () => {
                    if (newCommand.value.key && newCommand.value.value) {
                        commands.value[newCommand.value.key] = newCommand.value.value;
                        sendBridge("AddReplacement", newCommand.value.key, newCommand.value.value);
                        newCommand.value = { key: '', value: '' };
                        showAddCommandModal.value = false;
                    }
                };

                const deleteCommand = (key) => {
                    delete commands.value[key];
                    sendBridge("RemoveReplacement", key);
                };

                const saveEditedCommand = () => {
                    commands.value[editCommand.value.key] = editCommand.value.value;
                    sendBridge("UpdateReplacement", editCommand.value.oldKey, editCommand.value.key, editCommand.value.value);
                    editCommand.value = { oldKey: '', key: '', value: '' };
                    showEditCommandModal.value = false;
                };

                const playAirdropSound = () => {
                    sendBridge("TestAirdropSound");
                };

                const playDrugSound = () => {
                    sendBridge("TestDrugSound");
                };

                const hotreload = () => {
                    sendBridge("Hotreload");
                };

                const updateCounter = (change) => {
                    sendBridge("changeCounter", change);
                };

                const setDrugLevel = (level) => {
                    drugData.value.level = level;
                    sendBridge("SetDrugLevel", level);
                };

                const setClickPositions = () => {
                    sendBridge("SetClickPositions");
                    console.log('Set click positions');
                };

                const isListening = ref(false);
                let currentKeys = new Set();

                const startListening = () => {
                newHotkey.value.key = "Drücke eine Taste...";
                isListening.value = true;
                currentKeys.clear();
                window.addEventListener("keydown", recordKeys);
                window.addEventListener("keyup", stopListeningOnKeyUp);
                };

                const recordKeys = (event) => {
                    event.preventDefault();

                    currentKeys.clear();

                    if (event.ctrlKey) currentKeys.add("Strg");
                    if (event.altKey) currentKeys.add("Alt");
                    if (event.shiftKey) currentKeys.add("Shift");

                    let keyName = event.key;

                    if (keyName === "Control" || keyName === "Strg" ||
                        keyName === "Shift" || keyName === "Alt") {
                        if (currentKeys.size > 0) {
                            newHotkey.value.key = Array.from(currentKeys).join("+") + "+...";
                        }
                        return;
                    }

                    if (event.location === 3) {
                        if (/^\d$/.test(keyName)) {
                            keyName = "Num" + keyName;
                        }
                        else if (keyName === "Decimal") keyName = "NumDecimal";
                        else if (keyName === "Add") keyName = "NumAdd";
                        else if (keyName === "Subtract") keyName = "NumSubtract";
                        else if (keyName === "Multiply") keyName = "NumMultiply";
                        else if (keyName === "Divide") keyName = "NumDivide";
                        else if (keyName === "Enter") keyName = "NumEnter";
                    } else {
                        if (keyName.length === 1) keyName = keyName.toUpperCase();
                    }

                    if (keyName.startsWith("Arrow")) keyName = keyName.replace("Arrow", "");
                    else if (keyName === " ") keyName = "Space";

                    currentKeys.add(keyName);

                    newHotkey.value.key = Array.from(currentKeys).join("+");

                    stopListening();
                };

                const stopListeningOnKeyUp = (event) => {
                stopListening();
                };

                const stopListening = () => {
                    isListening.value = false;
                    currentKeys.clear();
                    window.removeEventListener("keydown", recordKeys);
                    window.removeEventListener("keyup", stopListeningOnKeyUp);
                };

                const startListeningEdit = () => {
                    editHotkey.value.key = "Drücke eine Taste...";
                    isListeningEdit.value = true;
                    currentKeys.clear();

                    const recordKeysEdit = (event) => {
                        event.preventDefault();
                        currentKeys.clear();

                        if (event.ctrlKey) currentKeys.add("Strg");
                        if (event.altKey) currentKeys.add("Alt");
                        if (event.shiftKey) currentKeys.add("Shift");

                        let keyName = event.key;

                        if (keyName === "Control" || keyName === "Strg" ||
                            keyName === "Shift" || keyName === "Alt") {
                            if (currentKeys.size > 0) {
                                editHotkey.value.key = Array.from(currentKeys).join("+") + "+...";
                            }
                            return;
                        }

                        if (event.location === 3) {
                            if (/^\d$/.test(keyName)) {
                                keyName = "Num" + keyName;
                            }
                        } else {
                            if (keyName.length === 1) keyName = keyName.toUpperCase();
                        }

                        if (keyName.startsWith("Arrow")) keyName = keyName.replace("Arrow", "");
                        else if (keyName === " ") keyName = "Space";

                        currentKeys.add(keyName);
                        editHotkey.value.key = Array.from(currentKeys).join("+");
                        stopListeningEdit();
                    };

                    const stopListeningEdit = () => {
                        isListeningEdit.value = false;
                        currentKeys.clear();
                        window.removeEventListener("keydown", recordKeysEdit);
                    };

                    window.addEventListener("keydown", recordKeysEdit);
                };

                const saveEditedHotkey = () => {
                    if (editHotkey.value.oldKey !== editHotkey.value.key) {
                        delete hotkeys.value[editHotkey.value.oldKey];
                        sendBridge("DeleteHotkey", editHotkey.value.oldKey);
                    }

                    hotkeys.value[editHotkey.value.key] = editHotkey.value.command;
                    sendBridge("UpdateHotkey", editHotkey.value.oldKey, editHotkey.value.key, editHotkey.value.command);

                    editHotkey.value = { oldKey: '', key: '', command: '' };
                    showEditHotkeyModal.value = false;
                };


                const addHotkey = () => {
                if (newHotkey.value.key && newHotkey.value.command) {
                    hotkeys.value[newHotkey.value.key] = newHotkey.value.command;
                    sendBridge("AddHotkey", newHotkey.value.key, newHotkey.value.command);
                    newHotkey.value = { key: '', command: '' };
                    showAddHotkeyModal.value = false;
                }
                };

                const deleteHotkey = (key) => {
                delete hotkeys.value[key];
                sendBridge("DeleteHotkey", key);
                };


                const openURL = (url) => {
                    sendBridge("OpenUrlInDefaultBrowser", url);
                };

                const viewLogFile = (filename) => {
                    sendBridge("ViewLogFile", filename);
                };

                const downloadLogFile = (filename) => {
                    sendBridge("DownloadLogFile", filename);
                };

                const refreshLogs = () => {
                    sendBridge("RefreshLogs");
                };

                const getCurrentWeekCount = () => {
                    if (!counters.value?.WeeklyStats) return 0;

                    const now = new Date();
                    const startOfYear = new Date(now.getFullYear(), 0, 1);
                    const days = Math.floor((now - startOfYear) / (24 * 60 * 60 * 1000));
                    const weekNumber = Math.ceil((days + 1) / 7);
                    const currentWeekKey = `${now.getFullYear()}-W${weekNumber}`;

                    return counters.value.WeeklyStats[currentWeekKey] || 0;
                };

                const drugCooldownRemaining = ref(0);

                const formatDrugCooldown = (seconds) => {
                    if (seconds <= 0) return '00:00';
                    const min = Math.floor(seconds / 60);
                    const sec = seconds % 60;
                    return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
                };

                function updateDrugCooldownRemaining() {
                    if (drugData.value.DrugCooldownEnd) {
                        const now = new Date();
                        const end = new Date(drugData.value.DrugCooldownEnd);
                        const diff = Math.max(0, Math.floor((end - now) / 1000));
                        drugCooldownRemaining.value = diff;
                    } else {
                        drugCooldownRemaining.value = 0;
                    }
                }
                let drugCooldownInterval = null;
                const startDrugCooldownInterval = () => {
                    if (drugCooldownInterval) clearInterval(drugCooldownInterval);
                    updateDrugCooldownRemaining();
                    drugCooldownInterval = setInterval(updateDrugCooldownRemaining, 1000);
                };

                watch(() => drugData.value.DrugCooldownEnd, () => {
                    startDrugCooldownInterval();
                });

                onMounted(() => {
                    startDrugCooldownInterval();
                    setupWindowControls();
                    counters.value = {};

                    hotkeys.value = {
                        "Control+Num1": "/gm",
                        "Num2": "Teleport"
                        }
                        ;

                    commands.value = {
                    };


                    drugData.value = {
                    };

                    drugWorker.value = {
                    };



                    playerCount.value = '472';

                    weeklyStats.value = calculateWeeklyStats();
                    monthlyStats.value = calculateMonthlyStats();
                });

                return {
                    addNote,
                    updateNote,
                    deleteNote,
                    copyNote,
                    onInputNote,
                    noteSearchQuery,
                    filteredNotes,
                    formatDrugCooldown,
                    drugCooldownRemaining,
                    updateDrugCooldownRemaining,
                    drugCooldownInterval,
                    startDrugCooldownInterval,
                    activeTab,
                    navExpanded,
                    searchQuery,
                    showAddCommandModal,
                    showEditCommandModal,
                    showInfoCommandModal,
                    showInfoHotkeyModal,
                    editCommand,
                    saveEditedCommand,
                    openURL,
                    notes,
                    executerTextbox,
                    playerCount,
                    version,
                    commands,
                    counters,
                    drugData,
                    drugWorker,
                    hotkeys,
                    isListening,
                    startListening,
                    logFiles,
                    selectedLogContent,
                    selectedLogName,
                    settings,
                    newCommand,
                    newHotkey,
                    tabs,
                    links,
                    filteredCommands,
                    activeTabName,
                    getCurrentWeekCount,
                    updateDrugWorkerStatus,
                    updateThemeColors,
                    setStatusDrugWorker,
                    addCommand,
                    deleteCommand,
                    updateCounter,
                    setDrugLevel,
                    setClickPositions,
                    linkSearchQuery,
                    filteredLinks,
                    addHotkey,
                    deleteHotkey,
                    viewLogFile,
                    downloadLogFile,
                    refreshLogs,
                    updateReplacements,
                    updateAllData,
                    hotreload,
                    showWeekChart,
                    weeksToShow,
                    weeklyStats,
                    monthlyStats,
                    onExecuterTextChange,
                    hotkeySearchQuery,
                    showAddHotkeyModal,
                    showEditHotkeyModal,
                    isListeningEdit,
                    editHotkey,
                    filteredHotkeys,
                    startListeningEdit,
                    saveEditedHotkey,
                    playAirdropSound,
                    playDrugSound,
                    getBarHeight,
                    getWeekColorClass,
                    getMinWeeklyCount,
                    getMaxWeeklyCount,
                    getAverageWeeklyCount,
                    getLastWeekCount,
                    getWeekTrend,
                    getTrendColor,
                    loading
                };
            }
        }).mount('#app');